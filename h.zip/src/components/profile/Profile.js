import React from 'react'

function Profile() {
  return (
    <img src="https://cdn.dribbble.com/users/1577045/screenshots/4914645/media/028d394ffb00cb7a4b2ef9915a384fd9.png?compress=1&resize=800x600&vertical=top" alt="Girl in a jacket" width="500" height="600" />

  )
}

export default Profile
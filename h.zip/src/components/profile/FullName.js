import React from 'react'

function FullName({name}) {
  return (
    <div>{name}</div>
  )
}

export default FullName
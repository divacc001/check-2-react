import React from 'react'

 function Address({adres}) {
  return (
    <div>{adres}</div>
  )
}

export default Address
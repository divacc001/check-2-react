import Address from "./components/profile/Address";
import FullName from "./components/profile/FullName";
import Profile from "./components/profile/Profile";

function App() {
  let name="linda"
  let adres="manar"
  let profession="doctor"
  return (
    <div style={{display:"flex" }}>  
  <Profile />   
<div style={{display:"flex", justifyContent:"space-between", width:"300px", marginTop:"400px" }}>  
<FullName name={name} profession={profession}/>
<Address adres={adres}/>

</div>
    </div>
  );
}

export default App;
